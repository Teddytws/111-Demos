
#include "am.h"

void AdvancedMath::setPi(float p) {

	if (p >= 1)
		pi = p;
	else 
		pi = 1;
}

float AdvancedMath::getPi() {

	return pi;
}

float AdvancedMath::sin(int a) {


	return sin(a);
}


float AdvancedMath::circleArea(int r) {

	return 2*pi*r*r;
}












