
#ifndef SIMPLEMATH_H
#define SIMPLEMATH_H

class SimpleMath {

public:

	int add (int a, int b);
	int subtract (int a, int b);

	int pi;


};

#endif
