
#include "simpleMath.h"



int SimpleMath::add(int a, int b) {

 return a+b;

}

int SimpleMath::subtract(int a, int b) {

	return a-b;
}
