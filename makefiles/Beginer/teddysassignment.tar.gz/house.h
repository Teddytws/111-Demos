
#include <iostream>
#include <string>
using namespace std;
class House {


public:

void print();

string color;
int bedrooms;

};

