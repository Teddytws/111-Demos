

#include "house.h"


int main() {

House myhouse;

House scottsHouse;

myhouse.color = "blue";
myhouse.bedrooms = 10;

scottsHouse.color = "pink";
scottsHouse.bedrooms = 0;

myhouse.print();
scottsHouse.print();





	return 0;
}