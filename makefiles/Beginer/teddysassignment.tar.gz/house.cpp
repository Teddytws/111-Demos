

#include "house.h"


void House::print() {

	cout << color << endl;
	cout << bedrooms << endl;

}


